<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('posts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->timestamps();
            $table->bigInteger('id_create');
            $table->string('create_by');
            $table->boolean('del_active')->default($value=true);

            $table->string('urlPicture');
            $table->string('title')->nullable();
            $table->string('content')->nullable();
            $table->string('type');
            $table->string('descreption')->nullable();
            $table->string('typeNew');
            $table->date('date');
            $table->string('sologan')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('posts');
    }
}
