<?php
$config = [
    'appName' => config('app.name'),
    'locale' => $locale = app()->getLocale(),
    'locales' => config('app.locales'),
    'githubAuth' => config('services.github.client_id'),
];
?>
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo e(config('app.name')); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />
  <link rel="stylesheet" href="<?php echo e(mix('dist/css/app.css')); ?>">
</head>
<body>
  <div id="app"></div>

  
  <script>
    window.config = <?php echo json_encode($config, 15, 512) ?>;
  </script>

  
  <script src="<?php echo e(mix('dist/js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\thang\Desktop\adminDiseno\resources\views/index.blade.php ENDPATH**/ ?>