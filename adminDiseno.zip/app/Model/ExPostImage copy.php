<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ExPostImage extends Model
{
    //
}
