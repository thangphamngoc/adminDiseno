<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Home extends Model
{
    protected $attributes = [
        'numerNick'=>0,
        'numberAdd'=>0,
        'numberDayAdd'=>0,
        'numberdayNoAdd'=>0,
    ];
   
}
