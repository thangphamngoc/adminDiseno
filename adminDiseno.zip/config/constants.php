
<?php
return [
    'app_type' => [
        'system' => 'SYS',
        'plus' => 'PLUS',
        'employee' => 'EMPLOYEE',
    ]
];